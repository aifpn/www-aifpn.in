const s={is_dev:!1,base_url:"https://aifpn.in"};export{s as c};
