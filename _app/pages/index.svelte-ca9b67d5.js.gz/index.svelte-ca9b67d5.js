import{S as t,i as e,s as o}from"../chunks/vendor-3bd315f7.js";class n extends t{constructor(s){super();e(this,s,null,null,o,{})}}export{n as default};
